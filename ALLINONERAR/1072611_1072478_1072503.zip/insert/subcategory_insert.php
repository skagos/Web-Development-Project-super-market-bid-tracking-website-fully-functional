<?php 
	
  $connect = mysqli_connect("localhost","root","","projectdatabase");

  $filename = "subcategory_insert.json";

  $data = file_get_contents($filename);

  $array = json_decode($data, true);

  foreach($array as $row){
    $sql = " INSERT INTO subcategory(subcategory_id,subcategory_name,category_id) VALUES ('".$row["subcategory_id"]."','".$row["subcategory_name"]."','".$row["category_id"]."')";

    mysqli_query($connect, $sql);

  }
echo "ROYFEN PIPEN PIPEN";