<?php 
	
  $connect = mysqli_connect("localhost","root","","projectdatabase");

  $filename = "shop_data.json";

  $data = file_get_contents($filename);

  $array = json_decode($data, true);

  foreach($array as $row){
    $sql = " INSERT INTO shop(shop_id,name,shop,longitude,latitude) VALUES ('".$row["shop_id"]."','".$row["name"]."','".$row["shop"]."','".$row["longitude"]."','".$row["latitude"]."')";

    mysqli_query($connect, $sql);

  }
echo "Επιτυχής ενημέρωση δεδομένων καταστημάτων";