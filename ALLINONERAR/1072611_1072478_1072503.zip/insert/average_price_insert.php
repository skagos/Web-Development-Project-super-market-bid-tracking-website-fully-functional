<?php 
	
  $connect = mysqli_connect("localhost","root","","projectdatabase");

  $filename = "average_price.json";

  $data = file_get_contents($filename);

  $array = json_decode($data, true);

  foreach($array as $row){
    $sql = " INSERT INTO average_price(product_id,product_name,week_start_date,average_price) VALUES ('".$row["product_id"]."','".$row["product_name"]."','".$row["week_start_date"]."','".$row["average_price"]."')";

    mysqli_query($connect, $sql);

  }
echo "Επιτυχής ανέβασμα εβδομαδιαίων τιμών";