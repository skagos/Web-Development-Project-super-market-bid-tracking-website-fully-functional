<?php 
	
  $connect = mysqli_connect("localhost","root","","projectdatabase");

  $filename = "poytsa2.json";

  $data = file_get_contents($filename);

  $array = json_decode($data, true);

  foreach($array as $row){
    $sql = " INSERT INTO category(category_id,category_name) VALUES ('".$row["category_id"]."','".$row["category_name"]."')";

    mysqli_query($connect, $sql);

  }
echo " Επιτυχής ανέβασμα κατηγοριών";