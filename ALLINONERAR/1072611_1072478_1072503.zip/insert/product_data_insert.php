<?php 
	
  $connect = mysqli_connect("localhost","root","","projectdatabase");

  $filename = "products2.json";

  $data = file_get_contents($filename);

  $array = json_decode($data, true);

  foreach($array as $row){
    $sql = " INSERT INTO product(product_id,product_name,category_id,subcategory_id) VALUES ('".$row["product_id"]."','".$row["product_name"]."','".$row["category_id"]."','".$row["subcategory_id"]."')";

    mysqli_query($connect, $sql);

  }
echo "Επιτυχής ενημέρωση προιόντων";